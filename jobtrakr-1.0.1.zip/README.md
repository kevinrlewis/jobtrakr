# jobtrak
website using node.js, express, pug, and mongodb

##brief
jobtrak to track job descriptions from applied jobs
