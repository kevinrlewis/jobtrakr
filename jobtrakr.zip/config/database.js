// config/database.js
// url of mongodb
module.exports = {

    'url' : process.env.MONGODB_URI || 'mongodb://admin:8891607453@ds243335.mlab.com:43335/jobtrakr-dev'

};
